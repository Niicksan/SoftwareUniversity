﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Configurations
{
    public class Configuration 
    {
        public const string ConnectionString = @"Data Source=(local)\SQLEXPRESS; Initial Catalog = FootballBetting; Integrated Security = true";
    }
}
