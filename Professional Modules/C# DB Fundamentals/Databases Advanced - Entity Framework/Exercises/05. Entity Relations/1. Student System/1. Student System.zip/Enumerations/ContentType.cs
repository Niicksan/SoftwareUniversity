﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Enumerations
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}