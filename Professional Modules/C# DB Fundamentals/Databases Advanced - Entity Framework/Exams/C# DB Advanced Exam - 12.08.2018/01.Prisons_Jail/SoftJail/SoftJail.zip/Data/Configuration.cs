﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
